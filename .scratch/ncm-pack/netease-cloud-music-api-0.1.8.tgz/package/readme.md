####相关文章
[网易云音乐api整理](http://qianzewei.com/2015/12/10/%E7%BD%91%E6%98%93%E4%BA%91%E9%9F%B3%E4%B9%90api%E6%95%B4%E7%90%86/)

####文档

所有函数的参数均为两个: `params`和`callback`
params为包含所有参数的`object`
callback为回调函数`function(error, data)`

**login** 登录

    {
      "phone": 13312345678,
      "password": "password"
    }
**getPlaylist** 获取用户歌单列表

    {
      offset: 0,
      limit: 30,
      uid: 用户id
    }

**getSongDetail** 获取


getPlayUrl
getImgUrl
getLyric
search